package models;

public interface UserBase{
	public String getName();
	public String getPassword();
	public UserLevel Level();
}