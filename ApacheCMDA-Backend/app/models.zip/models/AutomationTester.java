package models;

public class AutomationTester extends Tester{
	@Override
	public String getName(){
		return "autoTester";
	}

	@Override
	public String getPassword(){
		return "autoTester";
	}
}