package models;

public interface UserLevel{
	public String getLevel();
}