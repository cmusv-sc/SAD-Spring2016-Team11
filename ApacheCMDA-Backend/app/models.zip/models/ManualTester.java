package models;

public class ManualTester extends Tester{
	@Override
	public String getName(){
		return "mTester";
	}

	@Override
	public String getPassword(){
		return "mTester";
	}
}